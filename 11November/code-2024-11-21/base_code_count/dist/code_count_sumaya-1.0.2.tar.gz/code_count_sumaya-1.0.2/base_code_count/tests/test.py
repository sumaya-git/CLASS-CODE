print("hello")
# this is a print above


x = 4 + 2


print(x)
